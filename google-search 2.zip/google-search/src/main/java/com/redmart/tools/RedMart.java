package com.redmart.tools;

import net.thucydides.core.annotations.Feature;

public class RedMart {
	
	  @Feature
	    public class LandingPage {
		  	public class SignUp {
		  		
		  	}
	        public class Login {
	        }
	    }

	
}
