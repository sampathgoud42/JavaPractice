
public interface Dinteface {

	//Diff Between Interface and Abstract
	//Abstarct doesn't have class prefixed
	//Almost Same as Abstarct class but every method in interface is a abstract method
	//But Java 8 introduced "Defaukt method" which allows us to add new methods with declerations and definations
	//Every variable in interface is a static final variable.. Eg: Loanrate=13.99 is always constant in Bakloan app
	
	//eg: WebDriver driver= new FireFoxDriver();
	
	// WebDriver is an interface, FirefoxDriver is an implementation class of webDriver


}
