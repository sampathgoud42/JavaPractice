import java.util.Scanner;


public abstract class AbstractCalc {
	
	private double num1;
	private double num2;
	private double sum;
	private double substraction;
	private double multiplication;
	private double division;
	
	
	
	
	static Scanner input=new Scanner(System.in);
	
	public void setNum1(double n1){
		System.out.println("Enter num1: ");
		num1=input.nextDouble();
	}
	
	public void setNum2(double n2){
		System.out.println("Enter num2: ");
		num2=input.nextDouble();
	}
	
	
	public String  enterOperator(String ope){
		System.out.println("Enter Operator: ");
		ope=input.next();
		return ope;
	}
	
	public void  calculate(String ope){
		String inpuOp = enterOperator(ope);
		
		switch(inpuOp){
		
		case "+":
			sum=num1+num2;
			System.out.println(sum);
			break;
		case "-":
			substraction=num1-num2;
			System.out.println(substraction);
			break;
		case "*":
			multiplication=num1*num2;
			System.out.println(multiplication);
			break;
		case "/":
			division=num1/num2;
			System.out.println(division);
			break;
				
			
		}
		
	}
	

}
