import java.util.ArrayList;



public class CalculatorMain extends AbstractCalc{

	static double n1, n2;
	static String op;
	
	public static void main (String[] args){
		

		
		AbstractCalc a=new CalculatorMain();

		a.setNum1(n1);
		a.setNum2(n2);
		a.calculate(op);
		
	}

	
	
}
