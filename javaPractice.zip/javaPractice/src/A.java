
public class A {
	//Class is a collection of variables and Methods
	//Class is a blue print which is used to implement actual methods using different variables
	//*** UML diagram of class****///
		//Class A   ......Home
		//number: int; text: String;    ......TV, refrigerator, AC
		//m1(); m2() ............ House Owner, ad family members
	
	private int i=10;  // private variable can be accessed only within class,
	int a=11;
	int b=12;
	// If we want it access in other calss, we need to create Object with reference
	int j;
	float f=0.0f;
	String s1;
	
	A(){
		//default constructor
	}
	
	//Constructor can be overloaded within class but not overridden bcz costructor must have same name as class name
	
	A(int m){  //parameterized constructor
		j=m;
	}
	
	public void constr1(){
		System.out.println(j);
	}
	public void m1(){
		
		System.out.println("method1 class A: Study classA/Maths");
	}
	
	public void m2(){
		
		System.out.println("method2 class A");
	}

	public void m3(){
		int j=20; int l=30;
		System.out.println("method3 class A"+j+l);
	}
	
	// Encapsulation: wrapping all methods in single place
	public void m4(int k){
		i=k; //called private variable here
		System.out.println("method1 class A"+k+"  "+i+"  "+a);
	}

	
	public A r1(){
		
		System.out.println("ClassA: methd r1 with Object as returntype");
		return new A();
	}
	
	public String r2(){
		System.out.println("ClassA: methd r2 with String as returntype");
		return "test";
	}
	public int r3(){
		System.out.println("ClassA: methd r3 with int as returntype");
		return 99;
	}

}
