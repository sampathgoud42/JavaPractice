
public class C extends EAbstract {
	
//Inheriting the properties of abstraction class
//So here we MUST implement all abstract methods of Parent class
//Example, For bankloan we always implment document, verification and approval methods for all new applications

//We cannot create Object forAbstarct class.
public static void main (String args[]){

	//EAbstract abb= new EAbstract(); // We cannot create Object forAbstarct class.

}
	
	public void documents(){
		System.out.println("Bankloan Documents");
	}
	
	public void verification(){
		System.out.println("Bankloan Verification");
	}

	public void approval(){
		
		System.out.println("Bankloan Approval");
	}

}
