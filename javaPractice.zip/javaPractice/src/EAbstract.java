
public abstract class EAbstract {
	// Overriding concept
	// Abstract class and mthods should be prefixed with abstract
	//There's no implemetation for abstract methods
	//Whichever class is using abstract class must implmenet all abstract methods declared in abstract class
	//Abstarct class can have non-abstarct actual methods
	
	public abstract void documents();
	public abstract void verification();
	public abstract void approval();
	
	
	//non abstract method
	
	public void testab1(){
		System.out.println("Abstract class method implemeted");
	}
	

}
