
public class B extends A {  //inheritance is reuasability reusing the methods of class A here
	
	int k=888; //these instance variables stored inside class, not methods. wheras local varibales are stored inside mthods
		
		//instant variables have default values int=0; char=''(space); flaot=0.0f; boolan=false;  
		//local variables doesn't have default values
		//datatypes sizes int=4bytes; long=8bytes; short=2bytes; byte=1byte
		//dataTypes sizes char=2bytes; float=4bytes; double=8bytes
				
	int i =777;
	int a=666;
	
	public static int sint=500; // static variable, static loading always be 500
	
	B(){
		 //default constructor
		//Constructor can be overloaded within class but not overridden bcz costructor must have same name as class name
		// Constructor doesn't have return type
	}
	public static void main (String args[]){
		A a = new B(); //Upcasting; Creating Object for Child class with refering parent class 
		A a1= new A(); //a and a1 both are same but a1 cannot have methods implemented in class B
		A a2= new A(99); // parameterized constructor a2.j should return 99
//		B b1 = new A(); // Downcasting: NEVER WORKS WITH JAVA
		B b = new B(); // creates object and stored in heap memory
		
		b.i=50; // will b stored in heap memory, garbage colector will clean this data after execution, hence memory utiization
		//dynamic loading
		
		b.m1(); //Polymorphism (Overriding)  and encapsulation
		b.m1(100); //Polymorphism (Overlaoding within class)
		b.m2("Hello Investor"); //Overloading in two diff classes with different size
		a.m2(); // Inheritance
		b.m1(a.f); //Polymorphism (Overlaoding within class wit same size but different data type)
		
		b.r1();
		System.out.println(b.k+" "+b.i+" "+b.a+" "+b.b); //overhiding only for variables,
		//ie overhiding the actual variable of parent class with variable declared in child class 
		a.m4(b.a);
		
		System.out.println(a2.j);// here in a2.j "." s access resolver
		b.bClassOnly();
		// a1.bClassOny(); //ERROR bcz calss A referece is declared for class A object only
		
		
		//PASCAL CASING eg: class TestLogin
		//CAMEL CASING eg: methods testLogin
		
		
	}
	
	//LATE Binding: Runtime Overriding is an example for Late Binding
	//EARLY Binding: compile time, overlaoding is an example for Early Binding, bcz in overloading arguements will differ
	
	public void m1(){
		f=1.0f;   // here float f is declared as public(default) in class so NO ERROR.
		int ii=15; //local varibales are stored inside mthods
//		i=10;  // ERROR: here integer i is declared as private in class A
		System.out.println("Class B m1 overiding: child studying ScienceClassB instead of MathsorClassA"); 
		//Overriding can be done only in two different classes which is having Parent-Child relationship
		// Parent class A ask u to Study Maths but you overriden with Science, ie you want to Study Science
	}
	
	
	public void m1(int i){ //method with name "m1" is present in this Class B with zero arguments/parameters
		System.out.println("Class B m1 overloading within class");
		//Overloading can be done in both within class and two different classes with parent-Child relationship.
		//Overloading is nothing but adding some extra to exting method
		//eg: parent asked you to Study maths, but child studying Science along with Maths
		
	}
	
	
	public void m2( String s1){ 
		//method with name "m2" is present in Class A with zero arguments/parameters
		//But this method is having one Argument/parameter Eg: Dashavataram
		System.out.println("Class B m2 overloading in two diffrent classes with diffrent arguments/parameters");
	}
	
	
	
	public void m1(float fl){ //method with name "m1" is present in this Class B with zero arguments/parameters
		//method with name "m1" is present in Class A with one arguments/parameters with datatype as int
				//But this method is having one Argument/parameter  datatype as float
		fl=f;
		System.out.println("Class B m1 overloading within class with"+fl);
		
		//eg: parent asked you to Study maths, but child studying Science along with Maths
		
	}
	
	public B r1(){  //working
		//Overiding with return type - Only possible with co-varient objects
		//Object is the top of all types of classes
		//The return type of child class must be less than or equal to parent class
		System.out.println("ClassB: r1() with Object as returntype same returntype as A.r1()");
		return new B();
	} 
	
	/*
	public String r1(){ //SHOULD not be an error bcz "A.r1()" is an object return type
		//Overiding with return type - Only possible with co-varient objects
		//Object is the top of all types of classes
		//The return type of child class must be less than or equal to parent class
		System.out.println("ClassB: r1() with String as returntype which is less than returntype of A.r1()");
		return "class B.r1() as String";
	}

	public int r2(){ // 
		//retuntype in incompatible bcz int is less than "String A.r2()"
		//The return type of child class must be less than or equal to parent class
		System.out.println("ClassB: r2() with String as returntype which is lower than class A r1()");
		return 2;
	}
	
	public String r3(){ // retuntype in incompatible bcz int is less than "int A.r3()"
		//The return type of child class must be less than or equal to parent class
		System.out.println("ClassB: r2() with String as returntype which is lower than class A r1()");
		return "B Test r3()";
	}
	
*/	
	
	public void bClassOnly(){
		
		System.out.println("Class B Only method");
	}
}
