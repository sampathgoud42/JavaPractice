import java.util.ArrayList;
import java.util.Collections;


public class Array {
	
	public static void main (String[] args){
		
		Array a = new Array();
		a.reverseSt("test");
		
		a.reverse("Sampath Test");
		
		a.revWords("My First Test");
	}
	
	
	
public void reverseSt(String word){
		
		ArrayList<String> aword=new ArrayList<String>();
		
				
		for(int i=0; i<word.length();++i){
		
			aword.add(word.charAt(i) + "");
			
		}
		
		System.out.println(aword);
		
		ArrayList<String> rword= new ArrayList();
		
		Collections.reverse(aword);
		rword.addAll(aword);
		System.out.println(rword);
		
		
	}

public void reverse(String input){
	
	char[] ip= input.toCharArray();
	String afterR="";
	
	for(int i=ip.length-1;i>=0;i--){
		
		char a = ip[i];
		afterR +=a; 
	}
	
	System.out.println(afterR);
}


public void revWords(String inp){
	
	String[] ip= inp.split(" ");
	
	String afterR="";
	ArrayList<String> op = new ArrayList<String>();
	String[] opa=new String[3];
	
	for(int i=ip.length-1; i>=0; i--){
		
		String s= ip[i];
		op.add(s);
		afterR += s;
	}
	
	System.out.println(op);
}
}
