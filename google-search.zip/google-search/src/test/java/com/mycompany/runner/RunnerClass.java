package com.mycompany.runner;

import cucumber.api.CucumberOptions;
import net.serenitybdd.cucumber.CucumberWithSerenity;
import org.junit.runner.RunWith;

/**
 * Cucumber Runner Class
 */
@RunWith(CucumberWithSerenity.class)
@CucumberOptions(plugin = {"pretty"},features ="src/test/resources/features", glue = "com.mycompany.steps")
public class RunnerClass {
}

// In this class we can add test setup and tear down if necessary
